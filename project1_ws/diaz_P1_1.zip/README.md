# Readme

## Launch
I have created the launch file of my package **diaz_tutorials** in the launch directory. To run it you must run the following command in the workspace:

```python
roslaunch diaz_tutorials diaz_tutorials.launch
```