# Readme

## Launch
I have created the launch file of my package **diaz_tutorials** in the launch directory. To run it you must add the package to your workspace and then run the following command in the workspace:

```python
catkin_make
roscore
roslaunch diaz_tutorials diaz_tutorials.launch
```